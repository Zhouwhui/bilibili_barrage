# 1 导入相关库
import pandas as pd # 用于数据分析
import jieba # 用于分词统计出现的关键词
from wordcloud import WordCloud # 筛选词云图展示的词
# from pyecharts.charts import WordCloud
import matplotlib.pyplot as plt # 实现绘图可视化
from imageio import imread # 图片库，读取照片RGB内容，转换照片格式
# python通过调用warnings模块中定义的warn()函数来发出警告。我们可以通过警告过滤器进行控制是否发出警告消息
import warnings
warnings.filterwarnings("ignore") # 忽略警告信息

# 2 读取文本文件，并使用lcut()方法进行分词
with open("../result/dan_mu.txt",encoding="utf-8") as f:
    txt = f.read()
txt = txt.split()
data_cut = [jieba.lcut(x) for x in txt]
# data_cut

# 3 读取停用词（不展示的词）
with open("../util/stoplist.txt",encoding="utf-8") as f:
    stop = f.read()
stop = stop.split()
stop = [" ","道","说道","说"] + stop

# 4 去掉停用词之后的最终词
s_data_cut = pd.Series(data_cut) # 将数据转为一维数组，与Python基本的数据结构List也很相近，其区别是：List中的元素可以是不同的数据类型，而Array（Numpy）和Series中则只允许存储相同的数据类型
all_words_after = s_data_cut.apply(lambda x:[i for i in x if i not in stop])

# 5 词频统计
all_words = []
for i in all_words_after:
    all_words.extend(i)
word_count = pd.Series(all_words).value_counts()

# 6 词云图的绘制
def view():
    # 1）读取背景图片
    back_picture = imread("../image/老虎.jpg")

    # 2）设置词云参数
    wc = WordCloud(
        font_path="C:/Windows/Fonts/simfang.ttf",
                   background_color="white",
                   max_words=2000,
                   mask=back_picture,
                   max_font_size=200,
                   random_state=42
                  )
    wc2 = wc.fit_words(word_count) # 展示的词语

    # 3）绘制词云图
    plt.figure(figsize=(16,8))
    plt.imshow(wc2)
    plt.axis("off")
    plt.show()
    wc.to_file("../result/ciyun.png")