from demo import get_barrage,view_barrage
if __name__ == "__main__":
    url = "https://www.bilibili.com/video/BV1xp4y1U7Z4?from=search&seid=15475519335656829720"
    bvid = url.split("/video/")[1].split("?")[0]
    flag = get_barrage.begin(bvid)
    if flag:
        view_barrage.view()
    else:
        print("后台出现异常请重试！")