import requests
import json
import chardet
import re # 使用正则表达式解析数据

# 1.根据bvid请求得到cid
def get_cid(bvid):
    # bvid为bilibili播放视频时网址/video/后的值  --> https://www.bilibili.com/video/BV1ag4y1i7dP?
    url = 'https://api.bilibili.com/x/player/pagelist?bvid='+bvid+'&jsonp=jsonp'
    res = requests.get(url).text # 获取数据
    json_dict = json.loads(res) # 将数据转为json
    #pprint(json_dict)
    return json_dict["data"][0]["cid"] # 获取cid并返回

# 2.根据cid请求弹幕，解析弹幕得到最终的数据
"""
注意：哔哩哔哩的网页现在已经换了，那个list.so接口已经找不到，以下为新接口。
"""
def get_data(cid):
    final_url = "https://api.bilibili.com/x/v1/dm/list.so?oid=" + str(cid)
    final_res = requests.get(final_url)
    final_res.encoding = chardet.detect(final_res.content)['encoding']
    final_res = final_res.text
    pattern = re.compile('<d.*?>(.*?)</d>')
    data = pattern.findall(final_res)
    return data

# 3.保存弹幕列表 --> 保存到txt文本文件中
def save_to_file(data):
    with open("../result/dan_mu.txt", mode="w", encoding="utf-8") as f:
        for i in data:
            f.write(i)
            f.write("\n")

# 4.开始爬取数据并返回执行状态
def begin(bvid):
    try:
        cid = get_cid(bvid)
        data = get_data(cid)
        save_to_file(data)
        return True
    except:
        return False